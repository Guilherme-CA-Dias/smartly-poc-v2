export default async function getOAuthConfig({
  connectorParameters: { clientId, clientSecret, scopes },
  connectionParameters: { subdomain },
}) {
  return {
    clientId,
    clientSecret,
    authorizeUri: `https://${subdomain}.bynder.com/v6/authentication/oauth2/auth`,
    tokenUri: `https://${subdomain}.bynder.com/v6/authentication/oauth2/token`,
    scopes: scopes ?? ["offline", "current.user:read", "asset:read", "asset:write", "collection:read", "meta.assetbank:read"],
  }
}
