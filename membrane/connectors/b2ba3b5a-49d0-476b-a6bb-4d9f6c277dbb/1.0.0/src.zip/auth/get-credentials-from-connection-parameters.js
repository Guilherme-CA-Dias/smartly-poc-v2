export default async function({ connectionParameters }) {
  const tokenUrl = 'https://auth.sitecorecloud.io/oauth/token';
  const audience = connectionParameters.audience || 'https://api.sitecorecloud.io';
  
  const body = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: connectionParameters.clientId,
    client_secret: connectionParameters.clientSecret,
    audience: audience
  });

  const response = await fetch(tokenUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: body.toString()
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to obtain access token: ${response.status} - ${errorText}`);
  }

  const tokenData = await response.json();
  
  // Calculate expiration time (token expires in 24 hours / 86400 seconds)
  const expiresAt = Date.now() + (tokenData.expires_in * 1000);

  return {
    accessToken: tokenData.access_token,
    expiresAt: expiresAt,
    audience: audience,
    // Store original credentials for refresh
    clientId: connectionParameters.clientId,
    clientSecret: connectionParameters.clientSecret
  };
}