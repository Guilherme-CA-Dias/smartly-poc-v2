export default function fieldsFromApi({ fields }) {
  return { ...fields, file_type: fields['.tag'] }
}
