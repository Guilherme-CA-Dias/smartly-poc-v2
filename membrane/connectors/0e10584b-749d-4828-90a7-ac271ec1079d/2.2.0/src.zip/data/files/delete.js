export default async function del({ apiClient, id }) {
  await apiClient.post('files/delete_v2', {
    path: id,
  })
}
