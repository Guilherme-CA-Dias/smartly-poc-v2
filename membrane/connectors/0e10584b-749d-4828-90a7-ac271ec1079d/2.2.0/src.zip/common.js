export function getParentFolderPath(item) {
  if (item.path_lower && item.name) {
    return item.path_lower.substring(
      0,
      item.path_lower.length - item.name.length - 1,
    )
  }
  return ''
}
