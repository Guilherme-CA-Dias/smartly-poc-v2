export default async function list({
  apiClient,
  credentials,
  parameters,
  cursor,
  filter,
}) {
  const rootHeader = {
    'Dropbox-API-Path-Root': JSON.stringify({
      '.tag': 'namespace_id',
      namespace_id: credentials.rootNameSpaceId,
    }),
  }
  const fileType = filter?.file_type || parameters?.file_type

  const response = await fetchFilesAndFolders(
    apiClient,
    cursor,
    filter?.folder_id,
    rootHeader,
  )

  const enrichedEntries = await enrichEntriesWithParentData(
    apiClient,
    response,
    rootHeader,
  )

  return {
    records: filterRecords(enrichedEntries, fileType, filter?.folder_id),
    cursor: response.has_more ? response.cursor : null,
  }
}

async function fetchFilesAndFolders(apiClient, cursor, folderId, rootHeader) {
  const endpoint = cursor ? 'files/list_folder/continue' : 'files/list_folder'
  const requestData = cursor
    ? { cursor }
    : {
        path: folderId || '',
        recursive: true,
        include_deleted: false,
      }

  return await apiClient.post(endpoint, requestData, {
    headers: rootHeader,
  })
}

async function enrichEntriesWithParentData(apiClient, response, rootHeader) {
  const parentPaths = Array.from(
    new Set(response.entries.map(getParentFolderPath).filter(Boolean)),
  )

  const metaEntries = await Promise.all(
    parentPaths.map(async (path) => {
      const res = await apiClient.post(
        'files/get_metadata',
        { path, include_deleted: false },
        { headers: rootHeader },
      )
      return { path, id: res.id }
    }),
  )
  const parentFolderMap = Object.fromEntries(
    metaEntries.map(({ path, id }) => [path, id]),
  )

  return response.entries.map((entry) => ({
    ...entry,
    folder_id: parentFolderMap[getParentFolderPath(entry)],
  }))
}

function filterRecords(records, type, folderId) {
  let filteredRecords = records
  /*
   * Since Dropbox API returns the top parent folder itself
   * when we pass it to the 'path' parameter with the 'recursive' option set to true,
   * we need to remove it from the list of records to avoid duplication.
   */
  if (folderId) {
    filteredRecords = filteredRecords.filter((record) => record.id !== folderId)
  }

  if (type) {
    filteredRecords = filteredRecords.filter(
      (record) => record['.tag'] === type,
    )
  }

  return filteredRecords
}

function getParentFolderPath(entry) {
  if (entry.path_lower && entry.name) {
    return entry.path_lower.substring(
      0,
      entry.path_lower.length - entry.name.length - 1,
    )
  }
  return ''
}
