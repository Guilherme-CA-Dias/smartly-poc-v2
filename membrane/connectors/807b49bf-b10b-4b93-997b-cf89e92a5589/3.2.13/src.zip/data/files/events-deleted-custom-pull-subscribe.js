import {
  getSharedDrives,
  getLatestDriveActivityTime,
  ALL_ACTIVITIES_KEY,
} from 'common'

async function subscribeForDrive(apiClient, driveId, filter = 'DELETE') {
  return {
    timestamp: await getLatestDriveActivityTime(apiClient, driveId, filter),
  }
}

export default async function customPullSubscribe({ apiClient }) {
  const subscriptions = {}

  subscriptions['root'] = await subscribeForDrive(apiClient, 'root')

  const sharedDrives = await getSharedDrives(apiClient)
  if (sharedDrives?.length > 0) {
    await Promise.all(
      sharedDrives.map(async (drive) => {
        subscriptions[drive.id] = await subscribeForDrive(apiClient, drive.id)
      }),
    )
  }

  // Subscribe to all accessible activities to capture "Shared with me" files
  subscriptions[ALL_ACTIVITIES_KEY] = await subscribeForDrive(
    apiClient,
    ALL_ACTIVITIES_KEY,
  )

  return subscriptions
}
