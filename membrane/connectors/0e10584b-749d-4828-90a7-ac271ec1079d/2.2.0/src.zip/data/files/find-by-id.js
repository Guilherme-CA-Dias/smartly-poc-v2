import { getParentFolderPath } from 'common'

export default async function findById({ apiClient, credentials, id }) {
  const rootHeader = {
    'Dropbox-API-Path-Root': JSON.stringify({
      '.tag': 'namespace_id',
      namespace_id: credentials.rootNameSpaceId,
    }),
  }
  const res = await apiClient.post(
    'files/get_metadata',
    {
      path: id,
      include_deleted: false,
    },
    {
      headers: rootHeader,
    },
  )
  const parentFolderId = await extractParentFolderId(res, apiClient, rootHeader)
  let linkResponse = null
  try {
    linkResponse = await apiClient.post('files/get_temporary_link', {
      path: id,
    })
  } catch (error) {
    // It would raise an error if the file is not downloadable, but we can ignore it
  }
  return {
    record: {
      ...res,
      folder_id: parentFolderId,
      link: linkResponse?.link,
    },
  }
}

async function extractParentFolderId(item, apiClient, rootHeader) {
  const parentFolderPath = getParentFolderPath(item)
  if (parentFolderPath === '') {
    return undefined
  }
  const response = await apiClient.post(
    'files/get_metadata',
    { path: parentFolderPath, include_deleted: false },
    { headers: rootHeader },
  )
  return response.id
}
