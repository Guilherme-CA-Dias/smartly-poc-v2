export default async function search({ apiClient, query, cursor }) {
  if (cursor) {
    const response = await apiClient.post('files/search/continue_v2', {
      cursor,
    })

    return {
      records: response.matches.map((match) => match.metadata.metadata),
      cursor: response.has_more ? response.cursor : null,
    }
  }
  const response = await apiClient.post('files/search_v2', {
    query,
    options: {
      path: '',
      file_status: 'active',
      filename_only: false,
    },
  })

  return {
    records: response.matches.map((match) => match.metadata.metadata),
    cursor: response.has_more ? response.cursor : null,
  }
}
