 export default async function disconnect({ credentials }) {     
  const token = credentials.refresh_token ?? credentials.access_token
  await fetch(`https://oauth2.googleapis.com/revoke?token=${token}`, {                                                                                           
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },                                                                                            
  })                                                            
}