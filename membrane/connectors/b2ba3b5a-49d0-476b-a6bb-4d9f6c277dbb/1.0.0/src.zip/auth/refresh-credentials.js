export default async function({ credentials }) {
  const tokenUrl = 'https://auth.sitecorecloud.io/oauth/token';
  
  const body = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: credentials.clientId,
    client_secret: credentials.clientSecret,
    audience: credentials.audience || 'https://api.sitecorecloud.io'
  });

  const response = await fetch(tokenUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: body.toString()
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to refresh access token: ${response.status} - ${errorText}`);
  }

  const tokenData = await response.json();
  const expiresAt = Date.now() + (tokenData.expires_in * 1000);

  return {
    ...credentials,
    accessToken: tokenData.access_token,
    expiresAt: expiresAt
  };
}