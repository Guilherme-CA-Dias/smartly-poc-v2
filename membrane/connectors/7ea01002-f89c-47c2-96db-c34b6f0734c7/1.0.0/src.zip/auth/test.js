import { BadRequestError } from '@integration-app/sdk'

export default async function test({ apiClient }) {
  const response = await apiClient.post('/graphql', {
    query: '{ currentUser { id email name } }',
  })
  const user = response?.data?.currentUser
  if (!user?.id) {
    throw new BadRequestError(
      'Failed to retrieve current user. Verify the domain and access token.',
    )
  }
  return true
}
