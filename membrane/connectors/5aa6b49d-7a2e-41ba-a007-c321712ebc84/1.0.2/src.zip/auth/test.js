export default async function test({ apiClient }) {
  const response = await apiClient.get('/ping');
  return response.status === 'ok';
}