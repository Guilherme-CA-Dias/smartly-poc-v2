export default async function getConnectedAccountDetails({ apiClient }) {
  const rawFields = await apiClient.post('/users/get_current_account', null)
  const {
    name: { display_name },
    email,
  } = rawFields
  return { name: display_name, email, rawFields }
}
