export default async function getOAuthConfig({
  connectorParameters: { clientId, clientSecret, scopes },
  connectionParameters: { domain },
}) {
  return {
    clientId,
    clientSecret,
    authorizeUri: `https://${domain}/api/oauth/authorize`,
    tokenUri: `https://${domain}/api/oauth/accesstoken`,
    scopes: scopes ?? ['basic:read'],
  }
}
