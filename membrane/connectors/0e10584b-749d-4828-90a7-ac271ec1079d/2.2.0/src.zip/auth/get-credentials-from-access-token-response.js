import axios from 'axios'

export default async function getCredentialsFromTokenRes({ tokenResponse }) {
  const userAccountRes = await axios.post(
    'https://api.dropboxapi.com/2/users/get_current_account',
    null,
    {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenResponse.access_token}`,
      },
    },
  )
  return {
    ...tokenResponse,
    rootNameSpaceId: userAccountRes?.data?.root_info?.root_namespace_id,
  }
}
