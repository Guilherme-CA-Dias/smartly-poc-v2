export default async function({ apiClient }) {
  try {
    // Try to list projects from the XM Cloud Deploy API
    // This endpoint requires authentication and will validate our token
    const response = await apiClient.get('/api/projects/v1');
    
    // If we get here without an error, the authentication is working
    // The response should be an array of projects (could be empty)
    return Array.isArray(response) || (response && typeof response === 'object');
  } catch (error) {
    // Log the error for debugging
    console.error('Test failed:', error.message);
    throw error;
  }
}