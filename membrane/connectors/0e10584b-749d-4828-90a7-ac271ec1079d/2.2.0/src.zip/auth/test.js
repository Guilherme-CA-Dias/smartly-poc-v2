import { BadRequestError } from '@integration-app/sdk'

export default async function test({ apiClient }) {
  const response = await apiClient.post('/check/user', {
    query: 'foo',
  })
  if (response?.result !== 'foo') {
    throw new BadRequestError(
      'Connection test failed: response.result is ' + response?.result,
    )
  }
  return true
}
