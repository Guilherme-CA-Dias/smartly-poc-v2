import { BadRequestError } from "@integration-app/sdk"

export default async function test({ apiClient }) {
  const user = await apiClient.get("/api/v4/currentUser/")
  if (!user?.id) {
    throw new BadRequestError("Test failed: could not retrieve current user")
  }
  return true
}
